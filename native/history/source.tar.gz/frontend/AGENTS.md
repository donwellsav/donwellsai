<!--VITE PLUS START-->

# Using Vite+, the Unified Toolchain for the Web

This project is using Vite+, a unified toolchain built on top of Vite, Rolldown,
Vitest, tsdown, Oxlint, Oxfmt, and Vite Task. Vite+ wraps runtime management,
package management, and frontend tooling in a single global CLI called `vp`.
Vite+ is distinct from Vite, and it invokes Vite through `vp dev` and
`vp build`. Run `vp help` to print a list of commands and `vp <command> --help`
for information about a specific command.

Docs are local at `node_modules/vite-plus/docs` or online at
https://viteplus.dev/guide/.

## Review Checklist

- [ ] Run `vp install` after pulling remote changes and before getting started.
- [ ] Run `vp check` and `vp test` to format, lint, type check and test changes.
- [ ] Check if there are `vite.config.ts` tasks or `package.json` scripts
  necessary for validation, run via `vp run <script>`.
- [ ] If setup, runtime, or package-manager behavior looks wrong, run
  `vp env doctor` and include its output when asking for help.

<!--VITE PLUS END-->

## Frontend UI Rules

- Read the root `DESIGN.md` before adding or changing controls, styling, or
  reusable components.
- Before adding an interactive control, search `src/lib/components` for an
  existing shared component.
- Do not add new hand-styled native `<select>` controls. Use the shared
  typeahead/combobox components for single-choice selectors unless the native
  control is explicitly justified.
- Existing native selects are legacy exceptions, not examples to copy.

## Localization

- Keep the message catalogues in `messages/*.json` in sync. When you add,
  remove, or rename a user-facing key, update every locale listed in
  `project.inlang/settings.json` and keep their key sets identical.
- After changing a message catalogue or localized component, run
  `npm run i18n:compile` and `npm run check` when practical.
