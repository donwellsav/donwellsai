/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MoneyMoney } from './MoneyMoney';
export type ActivityBucket = {
  agent_minutes: number;
  automated_at_peak: number;
  cost: MoneyMoney;
  end: string;
  input_tokens?: number;
  interactive_at_peak: number;
  max_agents: number;
  output_tokens: number;
  start: string;
};
