/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DbProjectInventoryRow = {
  agents: number;
  distinct_cwds: number;
  enabled_rules_targeting: number;
  first_activity?: string;
  label: string;
  last_activity?: string;
  machines: number;
  project_key: string;
  recorded_as_original: boolean;
  sessions: number;
};
